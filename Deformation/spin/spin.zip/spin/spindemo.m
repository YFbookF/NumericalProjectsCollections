function spindemo

fn={
  'sphere'  4  [-160 -46]  [-160 -10]
  'monkey'  6  [  90 -60]  [  90 -60]
};

for c2=1:size(fn,1)
  load(['res/' fn{c2,1}])  
  jimesh(model,fn{c2,3},[fn{c2,1} '_inp'])
  model.vert=spin(model.tria,model.vert,model.rho*fn{c2,2});
  jimesh(model,fn{c2,4},[fn{c2,1} '_out'])
end

function jimesh(model,viw,fn)
  fig=figure(1);
  set(1,'Position',[108 10 1280 720])
  set(1,'Menubar','none')
  set(1,'Color',[ 232 232 232 ]/255)
  subplot('Position',[0 0 1 1])
  hnd=trisurf(model.tria',model.vert(1,:),model.vert(2,:),model.vert(3,:),rand(1,size(model.vert,2)));
  set(hnd,'FaceVertexCData',model.rho');
  alpha(0.999)
  set(hnd,'EdgeColor',0.2*[1 1 1]);
  set(hnd,'EdgeAlpha',0.2);
  axis tight
  axis equal
  axis off
  view(viw(1),viw(2))
  pause(0.01)
