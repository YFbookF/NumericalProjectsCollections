function biharmonicdemo

fn={
  'sphere3'   17.5 1   [97 0]
  'hook'      57.5 358 [-100 30] 
  'beethoven' 37.1 969 [-3 0]
};

for c2=1:size(fn,1)

  load(['res/' fn{c2,1}])
  
  %x=model.vert(1,:)- -1.659;
  %y=model.vert(2,:)- -1.615;
  %z=model.vert(3,:)- -4.028;
  %[tmp,mi]=min(x.*x+y.*y+z.*z)
  %return

  dB=biharmonic(model.tria,model.vert);
  
  sum(abs(imag(dB(:))))
  dB=real(dB);
  
  dB=dB*(fn{c2,2}/max(dB(:)));
  
  c1=fn{c2,3};  
  fig=figure(1);
  set(1,'Position',[108 10 720 720])
  set(1,'Menubar','none')
  set(1,'Color',[ 232 232 232 ]/255)
  
  subplot('Position',[0 0 1 1])
  %hnd=plot3(model.vert(1,c1),model.vert(2,c1),model.vert(3,c1),'r.')
  %set(hnd,'MarkerSize',15)
  %txt=text(model.vert(1,c1),model.vert(2,c1),model.vert(3,c1),'x')
  %set(txt,'Color',[1 0 0])
  %set(txt,'FontSize',20)
  %set(txt,'HorizontalAlignment','Center')
  %hold on
  hnd=trisurf(model.tria',model.vert(1,:),model.vert(2,:),model.vert(3,:));
  set(hnd,'FaceVertexCData',dB(:,c1));
  alpha(0.999)
  shading interp
  set(hnd,'EdgeColor',0.2*[1 1 1])
  set(hnd,'EdgeAlpha',0.2)
  
  hold on
  pnt=bicontour(model.tria,model.vert,dB(c1,:));
  for c1=1:2:size(pnt,2)
    c3=c1+[0:1];
    hnd=plot3(pnt(1,c3),pnt(2,c3),pnt(3,c3));
    set(hnd,'LineWidth',1.5)
    set(hnd,'Color',1*[1 1 1])
  end
  hold off
  axis tight
  axis equal
  axis off
  view(fn{c2,4})
  %str=['out/figure_' fn{c2,1} '.png'];
  %export_fig(str)
  %img=imread(str);
  %imwrite(img,['out/view_' fn{c2,1} '.jpg'],'Quality',95)
  %cmb=imresize(img,[NaN 240],'lanczos3');  
  %imwrite(cmb,['out/preview_' fn{c2,1} '.jpg'],'Quality',95)
  %pause(eps)
  %close all
  pause(eps)
end
