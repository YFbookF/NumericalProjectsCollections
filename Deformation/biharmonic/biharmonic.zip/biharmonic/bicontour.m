function pnt=bicontour(T,V,dBrow)

pnt={};
for c1=1:size(T,2)
  c3=T(:,c1);
  cel={};
  for c2=[c3([1 2]) c3([2 3]) c3([3 1])]
    i=c2(1);
    j=c2(2);    
    [asc,ind]=sort(dBrow(c2));
    prb=ceil(asc(1)):floor(asc(2));
    if ~isempty(prb)
      vrt=V(:,c2(ind));
      x=interp1(asc,vrt(1,:),prb);
      y=interp1(asc,vrt(2,:),prb);
      z=interp1(asc,vrt(3,:),prb);
      cel{1,end+1}=[x;y;z;prb];
    end
  end
  if ~isempty(cel)
    cel=cell2mat(cel);
    for c2=unique(cel(end,:))
      fnd=find(cel(end,:)==c2);
      if length(fnd)==2
        pnt{1,end+1}=cel(1:3,fnd);
      else
        fprintf('length %i\n',length(fnd))
      end
    end    
  end
end
pnt=cell2mat(pnt);

