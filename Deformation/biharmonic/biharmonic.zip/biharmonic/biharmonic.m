function [dB,Lc]=biharmonic(T,V)
% input: T (3xN) and V (3xM) so that
%  trimesh(T',V(1,:),V(2,:),V(3,:))
%  plots the triangular mesh
% output: dB (MxM) matrix where dB(i,j)
%  is distance between vertex i and j

nT=size(T,2);
nV=size(V,2);

AT=zeros(nT,1);
for c1=1:nT
  pnt=V(:,T(:,c1));
  AT(c1)=norm(cross(pnt(:,2)-pnt(:,1),pnt(:,3)-pnt(:,1)));
end

AV=zeros(nV,1);
ind={};
for c1=1:nT
  c3=T(:,c1);
  AV(c3)=AV(c3)+AT(c1);
  for c2=[c3 c3([2 3 1]) c3([3 1 2])]
    i=c2(1);
    j=c2(2);
    k=c2(3);
    v1=V(:,i)-V(:,k);
    v2=V(:,j)-V(:,k);
    fac=norm(v1)*norm(v2);
    if fac<eps
      fprintf('triangle %i is degenerate => ignored\n',c1)
    else
      val=cot( acos( dot(v1,v2) / fac ) );
      ind{end+1,1}=[
        i i  val
        i j -val
        j i -val
        j j  val
      ];
    end
  end
end

ind=cell2mat(ind);
Lc=sparse(ind(:,1),ind(:,2),ind(:,3),nV,nV);
gd=pinv(full(Lc*spdiags(6./AV,0,nV,nV)*Lc));
dia=diag(gd);
dB=zeros(nV);
for i=1:nV
  dB(:,i)=max(0,real(sqrt(gd(i,i)+dia-2*gd(:,i))));
end

%X=full(Lc*spdiags(6./AV,0,nV,nV)*Lc);
%[U,S,V]=svd(X);
%ds=diag(S);
%fnd=find(eps<ds);
%[numel(fnd) numel(ds)]
%ds(fnd)=1./ds(fnd);
%gd=V*diag(ds)*U';
